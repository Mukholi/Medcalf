<?php

// no direct access
defined('UNLIMITED_ELEMENTS_INC') or die;

class UniteCreatorAddonsViewProvider extends UniteCreatorAddonsView{
	
	protected $showButtons = true;
	protected $showHeader = false;
	
}
